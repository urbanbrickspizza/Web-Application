import DS from 'ember-data';
import { computed } from '@ember/object';

export default DS.Model.extend({
  firstName: DS.attr(),
  lastName: DS.attr(),
  email: DS.attr(),
  password: DS.attr(),
  group: DS.attr(),
  addressId: DS.attr(),
  addressType: DS.attr(),
  addressStreet: DS.attr(),
  addressStreet2: DS.attr(),
  addressCity: DS.attr(),
  addressState: DS.attr(),
  addressZip: DS.attr(),
  phone: DS.attr(),
  loyalty: DS.attr(),
  emailOptIn: DS.attr('boolean'),
  status: DS.attr(),
  created: DS.attr(),
  // orders: DS.hasMany('order', { async: true }),
  name: computed('firstName', 'lastName', function() {
    return this.get('firstName') + ' ' + this.get('lastName');
  }),
  loyaltysSpendRemainingAmount: computed('loyalty.progress_amount', 'loyalty.required_spend_amount', function() {
    let progress_amount = this.get('loyalty.progress_amount');
    let required_spend_amount = this.get('loyalty.required_spend_amount');
    if (progress_amount && required_spend_amount) {
      let value = required_spend_amount - progress_amount;
      value = value / 100;
      return value.toFixed(0).replace(/(\d)(?=(\d{3})+\.)/g, '$1,');
    }
    return 0;
  }),
  loyaltyAmountSpent: computed('loyalty.progress_amount', function() {
    let progress_amount = this.get('loyalty.progress_amount');
    if (progress_amount && progress_amount > 0) {
      let value = progress_amount / 100;
      return value.toFixed(0).replace(/(\d)(?=(\d{3})+\.)/g, '$1,');
    }
    return 0;
  }),
  loyaltyProgressPercent: computed('loyalty.progress_amount', 'loyalty.required_spend_amount', function() {
    let progress_amount = this.get('loyalty.progress_amount');
    let required_spend_amount = this.get('loyalty.required_spend_amount');
    if (progress_amount && required_spend_amount) {
      let percent = (progress_amount * 100) / required_spend_amount;
      return percent.toFixed(0);
    }
    return 0;
  })
});