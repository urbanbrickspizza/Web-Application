import DS from 'ember-data';
import ENV from 'urban-bricks-pizza/config/environment';
import { computed } from '@ember/object';
import { isEmpty } from '@ember/utils';

export default DS.Model.extend({
  accepts_tips_in_store: DS.attr(),
  accepts_tips_on_delivery: DS.attr(),
  accepts_tips_on_pickup: DS.attr(),
  categories: DS.attr(),
  category_names: DS.attr(),
  delivery_menu_url: DS.attr(),
  extended_address: DS.attr(),
  facebook_url: DS.attr(),
  foodler_url: DS.attr(),
  fulfillment_types: DS.attr(),
  hours: DS.attr(),
  image_url: DS.attr(),
  latitude: DS.attr(),
  locality: DS.attr(),
  longitude: DS.attr(),
  menu_url: DS.attr(),
  merchant_description: DS.attr(),
  merchant_description_html: DS.attr(),
  merchant_id: DS.attr(),
  merchant_name: DS.attr(),
  merchant_tip_preference: DS.attr(),
  name: DS.attr(),
  nearby_location_count: DS.attr(),
  newsletter_url: DS.attr(),
  open_state: DS.attr(),
  open_state_display: DS.attr(),
  opentable_url: DS.attr(),
  phone: DS.attr(),
  pickup_instructions: DS.attr(),
  pickup_menu_url: DS.attr(),
  postal_code: DS.attr(),
  ready_time_estimate_in_minutes: DS.attr(),
  region: DS.attr(),
  shown: DS.attr(),
  street_address: DS.attr(),
  twitter_url: DS.attr(),
  updated_at: DS.attr(),
  yelp_url: DS.attr(),



  slug: DS.attr(),
  title: DS.attr(),
  // revelId: DS.attr(),
  // revelSettings: DS.attr(),
  // revelMenu: DS.attr(),
  menu: DS.attr(),
  addressStreet: DS.attr(),
  addressStreet2: DS.attr(),
  addressCity: DS.attr(),
  addressState: DS.attr(),
  addressZip: DS.attr(),
  geo: DS.attr(),
  // phone: DS.attr(),
  // hours: DS.attr(),
  productOptions: DS.attr(),
  // delivery: DS.attr('boolean'),
  // deliveryRadius: DS.attr(),
  // tax: DS.attr('number'),
  distance: DS.attr('string', { defaultValue() { return ''; } }),
  // products: DS.hasMany('product', { async: true }),
  photo: computed(function() { return ENV.rootURL + 'img/photo-location-tmp.jpg'; }),
  pizzas: computed('menu.categories.@each.name', function() {
    let levelUpMenu = this.get('menu');
    if (!isEmpty(levelUpMenu)) {
      let pizzas = [];
      levelUpMenu.categories.filter(function(category) {
        if (category.type === 'pizza') {
          pizzas = category.items;
        }
      });
      return pizzas;
    } else {
      return [];
    }
  }),
  salads: computed('menu.categories.@each.name', function() {
    let levelUpMenu = this.get('menu');
    if (!isEmpty(levelUpMenu)) {
      let salads = [];
      levelUpMenu.categories.filter(function(category) {
        if (category.type === 'salad') {
          salads = category.items;
        }
      });
      return salads;
    } else {
      return [];
    }
  }),
  paninis: computed('menu.categories.@each.name', function() {
    let levelUpMenu = this.get('menu');
    if (!isEmpty(levelUpMenu)) {
      let salads = [];
      levelUpMenu.categories.filter(function(category) {
        if (category.type === 'panini') {
          salads = category.items;
        }
      });
      return salads;
    } else {
      return [];
    }
  }),
  wings: computed('menu.categories.@each.name', function() {
    let levelUpMenu = this.get('menu');
    if (!isEmpty(levelUpMenu)) {
      let salads = [];
      levelUpMenu.categories.filter(function(category) {
        if (category.type === 'wing') {
          salads = category.items;
        }
      });
      return salads;
    } else {
      return [];
    }
  }),
  pastas: computed('menu.categories.@each.name', function() {
    let levelUpMenu = this.get('menu');
    if (!isEmpty(levelUpMenu)) {
      let pastas = [];
      levelUpMenu.categories.filter(function(category) {
        if (category.type === 'pasta') {
          pastas = category.items;
        }
      });
      return pastas;
    } else {
      return [];
    }
  }),
  desserts: computed('menu.categories.@each.name', function() {
    let levelUpMenu = this.get('menu');
    if (!isEmpty(levelUpMenu)) {
      let salads = [];
      levelUpMenu.categories.filter(function(category) {
        if (category.type === 'dessert') {
          salads = category.items;
        }
      });
      return salads;
    } else {
      return [];
    }
  }),
  drinks: computed('menu.categories.@each.name', function() {
    let levelUpMenu = this.get('menu');
    if (!isEmpty(levelUpMenu)) {
      let salads = [];
      levelUpMenu.categories.filter(function(category) {
        if (category.type === 'drink') {
          salads = category.items;
        }
      });
      return salads;
    } else {
      return [];
    }
  })
});
