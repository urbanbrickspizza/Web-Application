import EmberRouter from '@ember/routing/router';
import Trackable from 'ember-cli-analytics/mixins/trackable';
import config from './config/environment';

const Router = EmberRouter.extend(Trackable, {
  location: config.locationType,
  rootURL: config.rootURL
});

Router.map(function() {
  this.route('intro');
  this.route('account', function() {
    this.route('welcome');
    this.route('register');
    this.route('login');
    this.route('recover');
    this.route('profile');
    this.route('rewards');
    this.route('settings');
    this.route('payment');
    this.route('addresses');
    this.route('orders');
  });
  this.route('locations');
  this.route('location', { path: '/locations/:location_id' }, function() {
    this.route('pizzas');
    this.route('paninis');
    this.route('pastas');
    this.route('salads');
    this.route('wings');
    this.route('desserts');
    this.route('drinks');
    this.route('product', { path: '/products/:product_id' });
  });
  this.route('order', function() {
    this.route('cart');
    this.route('edit', { path: '/edit/:item_id' });
    this.route('checkout');
    this.route('payment');
    this.route('confirmation', { path: '/orders/:order_id' });
    this.route('detail', { path: '/detail/:orderid' });
  });
  this.route('about');
  this.route('terms');
});

export default Router;
