import ENV from 'urban-bricks-pizza/config/environment';
import DS from 'ember-data';
import DataAdapterMixin from 'ember-simple-auth/mixins/data-adapter-mixin';

export default DS.RESTAdapter.extend(DataAdapterMixin, {
  host: ENV.APP.api.url,
  headers: {
    'UBP-AUTH': ENV.APP.api.key
  },
  authorize(xhr) {
    let { token } = this.get('session.data.authenticated');
    xhr.setRequestHeader('UBP-User-Token', `${token}`);
  },
  checkemail(query) {
    let bUrl = this._buildURL();
    let url = bUrl + '/users/checkemail';
    return this.ajax(url, 'POST', { data: query });
  },
  recover(query) {
    let bUrl = this._buildURL();
    let url = bUrl + '/users/recover';
    return this.ajax(url, 'POST', { data: query });
  },
  addresslist(query) {
    let bUrl = this._buildURL();
    let url = bUrl + '/users/addresslist';
    return this.ajax(url, 'POST', { data: query });
  },
  addresscreate(query) {
    let bUrl = this._buildURL();
    let url = bUrl + '/users/addresscreate';
    return this.ajax(url, 'POST', { data: query });
  },
  addressedit(query) {
    let bUrl = this._buildURL();
    let url = bUrl + '/users/addressedit';
    return this.ajax(url, 'POST', { data: query });
  },
  addressdelete(query) {
    let bUrl = this._buildURL();
    let url = bUrl + '/users/addressdelete';
    return this.ajax(url, 'POST', { data: query });
  },
  addressdelivery(query) {
    let bUrl = this._buildURL();
    let url = bUrl + '/users/addressdelivery';
    return this.ajax(url, 'POST', { data: query });
  },
  qrcode(query) {
    let bUrl = this._buildURL();
    let url = bUrl + '/users/qrcode';
    return this.ajax(url, 'POST', { data: query });
  },
  paymentmethod(query) {
    let bUrl = this._buildURL();
    let url = bUrl + '/users/paymentmethod';
    return this.ajax(url, 'POST', { data: query });
  },
  paymentcreate(query) {
    let bUrl = this._buildURL();
    let url = bUrl + '/users/paymentcreate';
    return this.ajax(url, 'POST', { data: query });
  },
  paymentdelete(query) {
    let bUrl = this._buildURL();
    let url = bUrl + '/users/paymentdelete';
    return this.ajax(url, 'POST', { data: query });
  },
  pastorders(query) {
    let bUrl = this._buildURL();
    let url = bUrl + '/users/pastorders';
    return this.ajax(url, 'POST', { data: query });
  },
  orderdetail(query) {
    let bUrl = this._buildURL();
    let url = bUrl + '/orders/detail';
    return this.ajax(url, 'POST', { data: query });
  },
  validateorder(query) {
    let bUrl = this._buildURL();
    let url = bUrl + '/orders/validateorder';
    return this.ajax(url, 'POST', { data: query });
  },
  validatestatus(query) {
    let bUrl = this._buildURL();
    let url = bUrl + '/orders/validatestatus';
    return this.ajax(url, 'POST', { data: query });
  },
  proposedorder(query) {
    let bUrl = this._buildURL();
    let url = bUrl + '/orders/proposed';
    return this.ajax(url, 'POST', { data: query });
  },
  completeorder(query) {
    let bUrl = this._buildURL();
    let url = bUrl + '/orders/complete';
    return this.ajax(url, 'POST', { data: query });
  },
  completestatus(query) {
    let bUrl = this._buildURL();
    let url = bUrl + '/orders/completestatus';
    return this.ajax(url, 'POST', { data: query });
  }
});