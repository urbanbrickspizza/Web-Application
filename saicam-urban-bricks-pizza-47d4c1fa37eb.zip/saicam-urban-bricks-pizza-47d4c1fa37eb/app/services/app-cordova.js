// import ENV from 'urban-bricks-pizza/config/environment';
import Service from '@ember/service';
import { inject as service } from '@ember/service';
// import EmberCordovaEventsMixin from 'ember-cordova/mixins/events';
import subscribe from 'ember-cordova-events/utils/subscribe';
import { isEmpty } from '@ember/utils';
import $ from 'jquery';

export default Service.extend({
  cordovaPlatform: service('ember-cordova/platform'),
  cordovaEvents: service('ember-cordova/events'),
  isCordovaRunning: false,
  isCordovaisIOS: false,
  isCordovaisAndroid: false,
  profile: service(),
  ubp: service(),
  brightnessOriginal: -1,
  cordovaReady: subscribe('cordovaEvents.deviceready', function() {
    let cordovaService = this;
    this.set('isCordovaRunning', true);
    // Platform
    let cordovaPlatform = this.get('cordovaPlatform');
    let device = cordovaPlatform.get('device');
    if (window.cordova.platformId === 'android') {
      this.set('isCordovaisAndroid', true);
      $('body').addClass('body-cordova-android');
    } else {
      this.set('isCordovaisIOS', true);
      $('body').addClass('body-cordova-ios');
      if (!isEmpty(device.model) && device.model === 'iPhone10,6') {
        $('body').addClass('body-cordova-ios-iphone-x');
      }
    }
    // Location
    let profileData = (!isEmpty(localStorage.profile) ? JSON.parse(localStorage.profile) : false);
    if (!isEmpty(profileData) && profileData.location === true) {
      this.get('profile').getLocation();
    }
    // In App Browser
    window.open = window.cordova.InAppBrowser.open;
    // Brightness
    let brightness = window.cordova.plugins.brightness;
    brightness.getBrightness(function(status) { cordovaService.set('brightnessOriginal', status); }, function() { return false; });
  }),
  cordovaResume: subscribe('cordovaEvents.resume', function() {
    this.get('ubp').getLocations();
    // Location
    let profileData = (!isEmpty(localStorage.profile) ? JSON.parse(localStorage.profile) : false);
    if (!isEmpty(profileData) && profileData.location === true) {
      this.get('profile').getLocation();
    }
  }),
  brightnessEnable() {
    let brightness = window.cordova.plugins.brightness;
    return brightness.setBrightness(1, function() { return true; }, function() { return false; });
  },
  brightnessDisable() {
    let brightness = window.cordova.plugins.brightness;
    let brightnessOriginal = this.get('brightnessOriginal');
    return brightness.setBrightness(brightnessOriginal, function() { return true; }, function() { return false; });
  },
  brightnessScreenOn(value) {
    let brightness = window.cordova.plugins.brightness;
    brightness.setKeepScreenOn(value);
    return true;
  },
});
