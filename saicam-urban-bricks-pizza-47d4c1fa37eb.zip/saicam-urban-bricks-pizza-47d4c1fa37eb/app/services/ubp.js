import ENV from 'urban-bricks-pizza/config/environment';
import Service from '@ember/service';
import { inject as service } from '@ember/service';
import { computed } from '@ember/object';
import { isEmpty } from '@ember/utils';

export default Service.extend({
  locations: null,
  store: service(),
  productImagesURL: ENV.APP.aws.productPhotosURL,
  q: null,
  init() {
    this._super(...arguments);
    this.set('locations', []);
    this.getLocations();
  },
  getLocations: function() {
    let self = this;
    let store = this.get('store');
    store.findAll('location').then(function(locations) {
      self.set('locations', locations);
    });
  },
  filteredLocations: computed('locations.@each.title', 'q', function() {
    // Constants
    // let controller = this;
    let locationList = this.get('locations');
    let q = this.get('q');
    let filteredLocations = [];
    let locations = [];
    // Search Query
    if (!isEmpty(locationList)) {
      if (!isEmpty(q) && q.length > 3) {
        q = q.replace(/\s+$/, '');
        locationList.forEach(function(location) {
          if (!isEmpty(location.get('title')) && !isEmpty(location.get('addressStreet')) && !isEmpty(location.get('addressCity')) && !isEmpty(location.get('addressState')) && !isEmpty(location.get('addressZip'))) {
            if (location.get('title').toLowerCase().indexOf(q.toLowerCase()) !== -1) {
              filteredLocations.pushObject(location);
            } else if (location.get('addressStreet').toLowerCase().indexOf(q.toLowerCase()) !== -1) {
              filteredLocations.pushObject(location);
            } else if (location.get('addressCity').toLowerCase().indexOf(q.toLowerCase()) !== -1) {
              filteredLocations.pushObject(location);
            } else if (location.get('addressState').toLowerCase().indexOf(q.toLowerCase()) !== -1) {
              filteredLocations.pushObject(location);
            } else if (location.get('addressZip').toString() === q.toString()) {
              filteredLocations.pushObject(location);
            }
          }
        });
        locations = filteredLocations;
      } else {
        locations = locationList;
      }
    }
    // Return Locations
    return locations;
  }),
  sortedLocationsDefinition: ['distance:asc', 'title:asc'],
  sortedLocations: computed.sort('filteredLocations', 'sortedLocationsDefinition'),
  appMode: ENV.APP.mode,
  appModeIsStaging: computed('appMode', function() {
    return ENV.APP.mode === 'staging';
  })
});