import ENV from 'urban-bricks-pizza/config/environment';
import Service from '@ember/service';
import { inject as service } from '@ember/service';
import { computed } from '@ember/object';
import { isEmpty } from '@ember/utils';
import { Promise } from 'rsvp';
import $ from 'jquery';
// import RSVP from 'rsvp';

Number.prototype.toRad = function() {
  return this * Math.PI / 180;
};

export default Service.extend({
  router: service(),
  session: service('session'),
  store: service(),
  i18n: service(),
  notifications: service('notification-messages'),
  cordova: service('app-cordova'),
  ubp: service(),
  order: service(),
  levelUpEmail: null,
  language: null,
  location: null,
  locationGeo: null,
  gettingLocation: false,
  payment: false,
  deliveryAddress: false,
  init() {
    let userLang = navigator.language || navigator.userLanguage;
    if (userLang.length > 3) {
      let langSplit = userLang.split('-');
      if (langSplit[0].length < 3){
        userLang = langSplit[0];
      } else {
        userLang = 'en';
      }
    }
    let result = $.grep(ENV.APP.languages, function(e){ return e.id === userLang; });
    if (result.length !== 1) {
      userLang = 'en';
    }
    let deliveryAddress = false;

    try {
      let profileData = false;
      if (!isEmpty(localStorage) && !isEmpty(localStorage.profile)) {
        profileData = JSON.parse(localStorage.profile);
        if (profileData.versionCode === ENV.APP.versionCode) {
          if (window.cordova) {
            this.get('cordova');
          } else {
            if (profileData.location) {
              this.getLocation();
            }
            if (!isEmpty(profileData.deliveryAddress)) {
              deliveryAddress = profileData.deliveryAddress;
            }
          }
        } else {
          if (window.cordova) {
            this.get('router').transitionTo('intro');
          }
          this.save();
        }
      } else {
        if (window.cordova) {
          this.get('router').transitionTo('intro');
        }
      }
    } catch (e) {
      console.log(e);
      // this.transitionToRoute('private-browsing-error');
    }

    let profileData = (localStorage.profile ? JSON.parse(localStorage.profile) : { language: userLang, location: null, deliveryAddress: deliveryAddress, versionCode: ENV.APP.versionCode });
    this.set('language', profileData.language);
    this.set('location', profileData.location);
    this.set('deliveryAddress', profileData.deliveryAddress);
    this.set('i18n.locale', 'en');
    localStorage.profile = JSON.stringify(profileData);
  },

  save() {
    let language = this.get('language');
    let location = this.get('location');
    let deliveryAddress = this.get('deliveryAddress');
    let profileData = { language: language, location: location, deliveryAddress: deliveryAddress, versionCode: ENV.APP.versionCode };
    localStorage.profile = JSON.stringify(profileData);
    return true;
  },

  account: computed('session.data.authenticated.user.id', function() {
    let store = this.get('store');
    let user = this.get('session.data.authenticated.user');
    if (!isEmpty(user)) {
      let userData = store.findRecord('user', user.id);
      this.get('order').setUser(userData);
      return userData;
    }
  }),

  updateLanguage(language) {
    this.set('language', language);
    this.set('i18n.locale', language);
    this.save();
  },

  setDeliveryAddress(address) {
    this.set('deliveryAddress', address);
    this.save();
  },

  getLocation() {
    var profile = this;
    this.set('gettingLocation', true);
    return new Promise(function(resolve, reject) {
      navigator.geolocation.getCurrentPosition(function getUserLocationSuccess(position) {
        profile.set('location', true);
        profile.set('locationGeo', { latitude: position.coords.latitude, longitude: position.coords.longitude } );
        profile.set('gettingLocation', false);
        profile.get('nearbyLocations');
        profile.save();
        resolve(position);
      }, function(res) {
        // console.log(res);
        if (!isEmpty(res.code) && res.code === 1) {
          profile.get('notifications').warning('You have denied ability to track your location. Go to your system preferences and enable it for this app.', { autoClear: false });
        } else {
          profile.get('notifications').warning('Failed to track your location');
        }
        profile.set('gettingLocation', false);
        profile.set('location', false);
        profile.save();
        reject(res);
      }, { timeout: 10000 });
    });
  },

  isLocationNull: computed('location', function() {
    return this.get('location') === null;
  }),

  nearbyLocations: computed('ubp.locations.@each.geo', 'location', 'locationGeo.latitude', 'locationGeo.longitude', function() {
    // Constants
    // let controller = this;
    let locations = this.get('ubp.locations');
    let profileLocation = this.get('location');
    let profileLocationGeo = this.get('locationGeo');
    let nearbyLocations = [];
    // User's Location
    if (!isEmpty(locations) && !isEmpty(profileLocation) && !isEmpty(profileLocationGeo)) {
      locations.forEach(function(location) {
        if (!isEmpty(location.get('geo'))) {
          let geo = location.get('geo');
          let lat2 = geo.latitude;
          let lon2 = geo.longitude;
          let R = 3961; // Miles
          let x1 = lat2-profileLocationGeo.latitude;
          let dLat = x1.toRad();  
          let x2 = lon2-profileLocationGeo.longitude;
          let dLon = x2.toRad();  
          let a = Math.sin(dLat/2) * Math.sin(dLat/2) + Math.cos((profileLocationGeo.latitude-0).toRad()) * Math.cos((lat2-0).toRad()) * Math.sin(dLon/2) * Math.sin(dLon/2);  
          let c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a)); 
          let d = R * c;
          let distance = Math.round(d);
          // let distance = d.toFixed(2);
          location.set('distance', distance);
          if (distance < 25) {
            nearbyLocations.pushObject(location);
          }
        }
      });
      if (!isEmpty(nearbyLocations)) {
        return nearbyLocations;
      } else {
        return [];
      }
    } else {
      return [];
    }
  }),
  nearbyLocationsDefinition: ['distance:asc'],
  nearbyLocationsSorted: computed.sort('nearbyLocations', 'nearbyLocationsDefinition'),
  sortedNearbyLocations: computed('nearbyLocationsSorted.@each', function() {
    let locations = this.get('nearbyLocationsSorted');
    if (locations.length > 4) {
      return this.get('nearbyLocationsSorted').splice(0, 4);
    } else {
      return this.get('nearbyLocationsSorted');
    }
  })
});