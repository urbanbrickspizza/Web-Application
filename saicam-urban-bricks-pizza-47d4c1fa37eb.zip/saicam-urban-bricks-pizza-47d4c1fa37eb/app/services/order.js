import Ember from 'ember';
// import ENV from 'urban-bricks-pizza/config/environment';
import Service from '@ember/service';
import { inject as service } from '@ember/service';
import { computed } from '@ember/object';
import { isEmpty } from '@ember/utils';
import { Promise } from 'rsvp';

export default Service.extend({
  items: [],
  location: null,
  user: null,
  delivery: null,
  notes: null,
  orderTime: null,
  isValidated: false,
  profile: service(),
  store: service(),
  i18n: service(),
  notifications: service('notification-messages'),
  router: null,
  init() {
    this._super(...arguments);
    this.initOrder();
    this.set('router', Ember.getOwner(this).lookup('router:main'));
    let self = this;
    // Listener
    var receiveMessage = (event) => {
      // var origin = event.origin || event.originalEvent.origin; // For Chrome, the origin property is in the event.originalEvent object.
      // Here you want to check origin, but in twiddle its null, try on ur machine...
      var data = event.data;
      if (!isEmpty(data) && !isEmpty(data.paymentID)) {
        if (data.returnCode === 0) {
          if (data.paymentID === self.get('vantivPaymentId')) {
            self.set('paymentTransactionId', data.paymentID);
            self.sendOrder('submit').then(function(order) {
              self.empty();
              self.get('router').transitionTo('order.confirmation', order);
            }, function(/* err */) {
              // console.log(err);
              self.get('notifications').error('There was an issue making order. Please contact location for further details.', {
                autoClear: true
              });
            });
          } else {
            // console.log(data);
            self.get('notifications').error('Insecure data transaction.', {
              autoClear: true
            });
          }
        } else if (data.returnCode === 102) {
          // User pressed "cancel" in vantiv form
          self.get('router').transitionTo('order.checkout');
        } else {
          // console.log(data);
          self.get('notifications').error(data.returnMessage, {
            autoClear: false
          });
          self.get('router').transitionTo('order.checkout');
        }
      }
    }
    window.addEventListener("message", receiveMessage, false);
  },
  initOrder(location, delivery) {
    // let self = this;
    let orderData = (localStorage.order ? JSON.parse(localStorage.order) : { location: null, items: [], delivery: false });
    if (!isEmpty(location)) {
      orderData.location = location.get('id');
      /*
      if (!isEmpty(location.get('delivery_charges'))) {
        let deliveryCharges = location.get('delivery_charges');
        deliveryCharges.foreach(function(item) {
          let itemAmount = item.amount + '00';
          self.set('deliveryFee', parseInt(itemAmount));
        });
      }*/
    }
    if (!isEmpty(delivery)) {
      orderData.delivery = delivery;
    }
    this.parseOrder(orderData);
  },
  parseOrder(orderData) {
    let self = this;
    let store = this.get('store');
    this.set('delivery', orderData.delivery);
    // let location = null;
    if (!isEmpty(orderData.location)) {
      store.findRecord('location', orderData.location).then(function(location) {
        self.set('location', location);
        if (!isEmpty(orderData.items)) {
          let menu = location.get('menu');
          let items = [];
          if (!isEmpty(menu)) {
            menu.categories.forEach((category) => {
              let products = category.items;
              if (!isEmpty(products)) {
                products.forEach((product) => {
                  orderData.items.forEach((item) => {
                    if (item.id === product.id) {
                      let itemObject = Ember.Object.create({
                        id: product.id,
                        name: product.name,
                        type: product.type,
                        image: product.image,
                        price: item.price,
                        quantity: item.quantity,
                        instructions: item.instructions,
                        options: item.options
                      });
                      items.pushObject(itemObject);
                    }
                  });
                });
              }
            });
          }
          self.set('items', items); 
          self.save();
        } else {
          self.set('items', []);
          self.save();
        }
      });
    } else {
      this.set('items', []);
      this.save();
    }
  },
  save() {
    let items = this.get('items');
    let location = this.get('location.id');
    let delivery = this.get('delivery');
    let orderData = { location: location, items: items, delivery: delivery };
    localStorage.order = JSON.stringify(orderData);
    return true;
  },
  setLocation(location) {
    let delivery = this.get('delivery');
    this.set('location', location);
    if (isEmpty(delivery)) {
      delivery = false;
    }
    this.initOrder(location, delivery);
  },
  setUser(user) {
    this.set('user', user);
    this.save();
  },
  setDelivery(value) {
    this.set('delivery', value);
    this.save();
  },
  add(item) {
    item.set('isNew', false);
    this.get('items').pushObject(item);
    this.save();
  },
  addCustom(item) {
    this.empty();
    let self = this;
    let orderData = {
      items: this.get('items')
    };
    orderData.items.pushObject(item);
    return new Promise(function(resolve) {
      self.parseOrder(orderData);
      resolve(true);
    });
  },
  remove(item) {
    this.get('items').removeObject(item);
    this.save();
  },
  empty() {
    this.set('items', []);
    this.set('location', null);
    this.set('delivery', false);
    this.save();
  },
  reorder(order) {
    this.empty();
    let self = this;
    let orderData = {
      items: order.get('items'),
      location: order.get('location.id'),
      delivery: order.get('delivery')
    };
    return new Promise(function(resolve) {
      self.parseOrder(orderData);
      resolve(true);
    });
  },
  itemsCount: computed('items.@each.quantity', function() {
    let items = this.get('items');
    let count = 0;
    if (!isEmpty(items)) {
      items.forEach(function(item) {
        count = count + parseInt(item.quantity);
      });
    }
    return count;
  }),
  priceDiscount: 0,
  priceService: 0,
  priceDelivery: 0,
  priceSubtotal: 0,
  /*
  priceSubtotal: computed('delivery', 'items.@each.price', 'items.@each.quantity', 'items.options.@each.price_amount', function() {
    let delivery = this.get('delivery');
    let items = this.get('items');
    let price = 0;
    let deliveryFee = this.get('priceDelivery');
    if (!isEmpty(items)) {
      items.forEach(function(item) {
        let productOptions = item.options;
        let productPrice = item.price;
        let selectedModifiersPrice = 0;
        if (!isEmpty(productOptions)) {
          productOptions.forEach(function(selectedModifier) {
            if (!isEmpty(selectedModifier.price_amount) && selectedModifier.price_amount > 0) {
              selectedModifiersPrice = selectedModifiersPrice + selectedModifier.price_amount;
            }
          });
        }
        if (selectedModifiersPrice > 0) {
          productPrice = productPrice + selectedModifiersPrice;
        }
        let productPriceTotal = productPrice * parseInt(item.quantity);
        price = price + productPriceTotal;
      });
    }
    if (delivery) {
      price = price + deliveryFee;
    }
    return price.toFixed(2);
  }),
  */
  isCheckoutCompleted: computed(/*'profile.account.phone', 'orderTime',*/ 'profile.payment', function() {
    // let phone = this.get('profile.account.phone');
    let payment = this.get('profile.payment');
    return payment; // !isEmpty(phone) && !isEmpty(orderTime);
  }),
  priceTax: 0,
  priceTotal: 0,
  completionAvailableAt: [],
  completionSoonestAvailableAt: null,
  completionUrl: null,
  completionUuid: null,
  sendOrder(type) {
    let order = this;
    let store = this.get('store');
    let adapter = store.adapterFor('order');
    let profile = order.get('profile');
    let items = order.get('items');
    let location = order.get('location');
    let delivery = order.get('delivery');
    let notes = order.get('notes');
    // let orderTime = order.get('orderTime');
    let deliveryAddressId = profile.get('deliveryAddress.id');
    let completionUrl = order.get('completionUrl');
    let completionUuid = order.get('completionUuid');
    /*
    let itemsData = [];
    items.forEach(function(item) {
      let itemData = {
        location: location.get('id'),
        product: item.product,
        slug: item.slug,
        title: item.title,
        category: item.category,
        quantity: item.quantity,
        options: item.options,
        customized: item.customized
      };
      itemsData.push(itemData);
    });
    */
    let orderRecord = {
      location: location.get('id'),
      delivery: delivery,
      deliveryAddressId: deliveryAddressId,
      notes: notes,
      // orderTime: orderTime,
      items: items
    };
    if (type === 'validate') {
      return new Promise(function(resolve, reject) {
        // Validate
        adapter.validateorder({order: orderRecord}).then(function(res) {
          let time = setInterval(function() {
            adapter.validatestatus({order_url: res.order.order_url}).then(function(res) {
              if (!isEmpty(res) && !isEmpty(res.order)) {
                if (res.order.state === 'externally_valid') {
                  clearInterval(time);
                  adapter.proposedorder({uuid: res.order.uuid}).then(function(res) {
                    order.set('completionAvailableAt', res.order.available_at);
                    order.set('completionUrl', res.order.order_completion_url);
                    order.set('priceDiscount', res.order.discount_amount);
                    order.set('priceService', res.order.service_fee_amount);
                    order.set('priceDelivery', res.order.delivery_fee_amount);
                    order.set('completionSoonestAvailableAt', res.order.soonest_available_at);
                    order.set('priceTax', res.order.tax_amount);
                    // order.set('tip_amount', res.order.tip_amount);
                    order.set('priceSubtotal', res.order.subtotal);
                    order.set('priceTotal', res.order.total_amount);
                    order.set('completionUuid', res.order.uuid);
                    resolve(res);
                  }, function(error) {
                    reject(error);
                  });
                } else if (res.order.state === 'externally_invalid') {
                  clearInterval(time);
                  reject(res);
                }
              }
            }, function(error) {
              clearInterval(time);
              reject(error);
            });
          }, 2000);
        }, function(error) {
          reject(error);
        });
      });
    } else if (type === 'complete') {
      return new Promise(function(resolve, reject) {
        // Complete
        adapter.completeorder({uuid: completionUuid}).then(function(res) {
          let time = setInterval(function() {
            adapter.completestatus({order_url: res.order.order_url}).then(function(res) {
              clearInterval(time);
              resolve(res);
            }, function(error) {
              clearInterval(time);
              reject(error);
            });
          }, 2000);
        }, function(error) {
          reject(error);
        });
      });
    }
  }
});