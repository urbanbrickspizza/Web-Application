import { helper } from '@ember/component/helper';
import { isEmpty } from '@ember/utils';
/* globals moment */

export function formatDate([format, date]) {
  if (typeof(format) !== 'string') {
    format = 'MMMM DD, YYYY';
  }
  if (isEmpty(date)) {
    date = Date.now();
  }
  return moment(date).format(format);
}

export default helper(formatDate);
