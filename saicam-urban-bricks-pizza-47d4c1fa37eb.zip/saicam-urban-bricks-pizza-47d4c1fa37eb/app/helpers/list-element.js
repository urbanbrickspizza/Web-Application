import { helper } from '@ember/component/helper';
import $ from 'jquery';

export function listElement([list, selected, display]) {
  if (selected && list) {
    try {
      var match = $.grep(list, function(e) { return e.id === selected; });
      if (display) {
        return match[0][display];
      }
      return match[0];
    } catch(err) {
      // console.log(err);
      // console.log(list);
      // console.log(selected);
      // console.log(display);
      return false;
    }
  } else {
    return '';
  }
}

export default helper(listElement);
