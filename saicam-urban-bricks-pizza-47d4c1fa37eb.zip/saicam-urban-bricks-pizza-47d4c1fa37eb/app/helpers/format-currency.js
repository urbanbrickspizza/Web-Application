import { helper } from '@ember/component/helper';
import { isEmpty } from '@ember/utils';

export function formatCurrency([value, basic]) {
  if (!isEmpty(value)) {
    value = value / 100;
    // value = parseFloat(value);
    if (!isEmpty(basic)) {
      return value.toFixed(0).replace(/(\d)(?=(\d{3})+\.)/g, '$1,');
    }
    return value.toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, '$1,');
  }
  return 0.00;
}

export default helper(formatCurrency);
