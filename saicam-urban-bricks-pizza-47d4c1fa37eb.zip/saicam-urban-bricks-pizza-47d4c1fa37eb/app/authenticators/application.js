import ENV from 'urban-bricks-pizza/config/environment';
import Base from 'ember-simple-auth/authenticators/base';
import { inject as service } from '@ember/service';
import { resolve } from 'rsvp';
import { reject } from 'rsvp';
import { isEmpty } from '@ember/utils';

export default Base.extend({
  ajax: service(),
  restore: function(data) {
    if (isEmpty(data.token)) {
      return reject();
    } else {
      return resolve(data);
    }
  },
  authenticate: function(credentials) {
    return this.get('ajax').request(ENV.APP.api.url + '/users/login', {
      method: 'POST',
      data: JSON.stringify({ user: { email: credentials.identification, password: credentials.password } }),
      contentType: 'application/json',
      dataType: 'json'
    });
  },
  invalidate: function() {
    return this.get('ajax').request(ENV.APP.api.url + '/users/logout', {
      method: 'DELETE',
      // data: JSON.stringify({ user: { email: credentials.identification, password: credentials.password } }),
      contentType: 'application/json',
      dataType: 'json'
    });
  }
});