/* eslint-env node */
'use strict';

module.exports = function(environment) {
  let ENV = {
    modulePrefix: 'urban-bricks-pizza',
    podModulePrefix: 'urban-bricks-pizza/pods',
    environment,
    rootURL: '', // /
    locationType: 'hash', // auto | hash
    EmberENV: {
      FEATURES: {
        // Here you can enable experimental features on an ember canary build
        // e.g. 'with-controller': true
      },
      EXTEND_PROTOTYPES: {
        // Prevent Ember Data from overriding Date.parse.
        Date: false
      }
    },

    APP: {
      mode: 'production',
      api: {
        url: 'https://order.urbanbricks.com/api',
        key: '23E561B2634DCFF80555B89AFA2630CC34C1C632BE6F1C0E6068897B7B6B7FA8'
      },
      aws: {
        productPhotosURL: 'https://s3-us-west-2.amazonaws.com/urban-bricks-product-photos'
      },
      languages: [
        { id: 'en', title: 'English' },
        { id: 'es', title: 'Español' }
      ],
      version: '1.2',
      versionCode: '18'
    },
    'ember-simple-auth': {
      authenticationRoute: 'account.welcome',
      store: 'session-store:local-storage'
    },
    analytics: {
      integrations: [
        {
          name: 'GoogleAnalytics',
          config: {
            id: 'UA-77556248-2'
          }
        }
      ]
    }
  };

  if (environment === 'development') {
    // ENV.APP.LOG_RESOLVER = true;
    // ENV.APP.LOG_ACTIVE_GENERATION = true;
    // ENV.APP.LOG_TRANSITIONS = true;
    // ENV.APP.LOG_TRANSITIONS_INTERNAL = true;
    // ENV.APP.LOG_VIEW_LOOKUPS = true;
  }

  if (environment === 'test') {
    // Testem prefers this...
    ENV.locationType = 'none';

    // keep test console output quieter
    ENV.APP.LOG_ACTIVE_GENERATION = false;
    ENV.APP.LOG_VIEW_LOOKUPS = false;

    ENV.APP.rootElement = '#ember-testing';
  }

  if (environment === 'production') {

  }

  return ENV;
};
