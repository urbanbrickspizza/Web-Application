const EmberFramework = require('corber/lib/frameworks/ember/framework');

module.exports = EmberFramework.extend({
});
